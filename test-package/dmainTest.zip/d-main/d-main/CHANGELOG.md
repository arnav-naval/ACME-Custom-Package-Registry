# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [1.0.2](https://github.com/medikoo/d/compare/v1.0.1...v1.0.2) (2024-03-01)

### Maintenance Improvements

- Upgrade `type` to v2 ([43b0eb8](https://github.com/medikoo/d/commit/43b0eb845d9efad3450e0e641ea1a827a5ba1966))

### [1.0.1](https://github.com/medikoo/d/compare/v0.1.1...v1.0.1) (2019-06-14)

## Changelog for previous versions

See `CHANGES` file
